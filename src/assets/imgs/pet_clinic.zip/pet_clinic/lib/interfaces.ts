export interface IPatient {
  name: string;
  // ...
}
