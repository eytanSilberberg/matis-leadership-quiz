export const db = "Database connection";
